var contador = 0;

function sumar1 () {
    contador = contador + 1;
    h1.innerText = contador;
    h1.classList.add('active');
}

var boton = document.getElementById('boton-sumar');
boton.addEventListener('click', sumar1);

var h1 = document.getElementById('numero');