// ESTADO DE LA APLICACIÓN
// =========================

// Esta es la variable más importante que tenemos, la que contiene
// el valor del contador en todo momento de la aplicación
var contador = 0;



// FUNCIONES
// =========================
// La idea de estas funciones es que hagan la menor cantidad posible de cosas

// Esta funcion agrega 1 al contador y actualiza la pantalla
function sumar1 () {
    contador = contador + 1;
    actualizarUI();
}

// Esta funcion resta 1 al contador si es que este tiene un valor mayor a 0
// para evitar que se muestren valores negativos y actualiza la pantalla
function restar1 () {
    if (contador > 0) {
        contador = contador - 1;
        actualizarUI();
    }
}

// Esta funcion vuelve el contador a 0 y actualiza la pantalla
function limpiar () {
    contador = 0;
    actualizarUI();
}

function actualizarUI () {
    // pone en el <h1> el valor actual del contador
    h1.innerText = contador;
}


// INTERACCIÓN DEL USUARIO
// =========================

// Declaro variables con los botones del HTML que le permiten al usuario modificar el estado
var botonSumar = document.getElementById('boton-sumar');
var botonRestar = document.getElementById('boton-restar');
var botonLimpiar = document.getElementById('boton-limpiar');

// Guardo en una variable el <h1> que refleja el valor del contador
var h1 = document.getElementById('numero');

// Asigno los event listeners para darle funcionalidad al click de cada botón
botonSumar.addEventListener('click', sumar1);
botonRestar.addEventListener('click', restar1);
botonLimpiar.addEventListener('click', limpiar);
