// crear variable y asignar valor
var miPeso = prompt('ingrese su peso');
var miPesoEnLaLuna = miPeso * 0.16;

// mostrar por terminal el valor de mi var
console.log(miPesoEnLaLuna);

// agrego al html un contenido
document.write(miPesoEnLaLuna);
